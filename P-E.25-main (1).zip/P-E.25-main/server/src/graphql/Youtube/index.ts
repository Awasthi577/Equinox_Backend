import { queries } from "./queries";
import { resolvers } from "./resolvers";

export const youtubeInfo = { queries, resolvers }