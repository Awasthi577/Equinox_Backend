export const queries = `
    getYtNewsOfSameParent(query:String, parentNewsId: String!, lim:Int, offset:Int): [MiniNews!]!
`