import { resolvers } from "./resolver"
import { typedefs } from "./typedefs"
import { mutations } from "./mutation"

export const newsSubscription = { resolvers, typedefs, mutations }

