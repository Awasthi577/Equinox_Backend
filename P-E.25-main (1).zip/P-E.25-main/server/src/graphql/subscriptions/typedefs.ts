export const typedefs = `#subscriptions
    type Subscription {
        newlyAddedNews: String!
    }
`

