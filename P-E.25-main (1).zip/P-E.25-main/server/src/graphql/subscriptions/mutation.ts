export const mutations = `
    notifyAddedNews: String!
`