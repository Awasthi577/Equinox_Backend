export const queries = `
    getBookmarks(limit: Int!,  offset: Int!): [MiniNews]!
`