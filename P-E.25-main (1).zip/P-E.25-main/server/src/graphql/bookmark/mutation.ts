export const mutations = `
    createBookmark(miniNewsId: String): String!
    deleteBookmark(miniNewsId: String): String!
    deleteAllBookmarks: String!
`