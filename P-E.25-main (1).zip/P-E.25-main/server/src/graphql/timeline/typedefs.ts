export const typeDefs = `#timeline
    scalar JSON
`