export const queries = `
    fetchTimeline(limit: Int!,  offset: Int!): [MiniNews]!
`