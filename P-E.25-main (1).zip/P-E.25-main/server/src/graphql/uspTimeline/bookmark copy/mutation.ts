export const mutations = `
    createTimeline(miniNewsId: String): String!
    deleteTimeline(miniNewsId: String): String!
    deleteAllTimeline: String!
`