import {queries} from "./queries"
import {resolvers} from "./resolver"
import { mutations } from "./mutation"

export const uspTimeLineInfo = { queries, resolvers, mutations }