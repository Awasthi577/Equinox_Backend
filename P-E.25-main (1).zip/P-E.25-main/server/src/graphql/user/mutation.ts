export const mutations = `
    createUser(email: String!, password: String!): String!
    updateUserName(newUserName: String): String!
`