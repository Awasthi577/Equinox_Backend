export const queries = `
    getXNewsOfSameParent(query:String, parentNewsId: String!, lim:Int, offset:Int): [MiniNews!]!
`